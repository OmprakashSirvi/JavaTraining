package com.einfo.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringjpatestApplicationTests {

	@Test
	void contextLoads() {
	}

}
